<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Strict//EN">
<html lang="en-US">

<head>
	<title>Capella</title>
	
	<link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>

<body class="contactbody">

	<div id="page-wrap" style="text-align:center;">

		
			
		<br /><br />
		
			
		<h1>Your message has been sent!</h1><br />
		
		<p><a href="../contact.html">Back to Contact Form</a></p>
	
	</div>
	

</body>

</html>